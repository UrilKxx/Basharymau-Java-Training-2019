create
    definer = root@localhost procedure user_registration(IN userName varchar(50), IN loginName varchar(50),
                                                         IN password varchar(50), IN roleShortName varchar(1),
                                                         OUT userId int, OUT reg bit)
begin
    insert into users (user_name, login, password_hash) VALUES (userName, loginName, MD5(password + '273905'));
    set userId = (select openclassroom.users.id from openclassroom.users where openclassroom.users.login = loginName);
    set reg = 0;
    if roleShortName = 's' then
            insert into user_roles (user_id, role_id) values(userId, 2);
            set reg = 1;
    elseif roleShortName = 't' then
            insert into user_roles (user_id, role_id) values(userId, 1);
            set reg = 1;
    end if;
end;

