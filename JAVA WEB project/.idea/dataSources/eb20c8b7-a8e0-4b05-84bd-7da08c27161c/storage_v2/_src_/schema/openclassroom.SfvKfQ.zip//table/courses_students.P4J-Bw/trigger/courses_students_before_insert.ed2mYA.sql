create definer = root@localhost trigger courses_students_BEFORE_INSERT
    before insert
    on courses_students
    for each row
BEGIN
	declare roleId int; 
	select role_id from user_roles where user_roles.user_id = NEW.user_id into roleId;
    if roleId != 2 then
		delete from courses_students where user_id = new.user_id;
    end if;
END;

