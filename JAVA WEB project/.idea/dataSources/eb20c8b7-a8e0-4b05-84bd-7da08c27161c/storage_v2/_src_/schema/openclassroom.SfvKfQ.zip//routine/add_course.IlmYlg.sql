create
    definer = root@localhost procedure add_course(IN courseName varchar(50), IN userLogin varchar(50))
BEGIN
	insert into openclassroom.courses (course_name, user_id) VALUES (courseName, (select id from openclassroom.users where openclassroom.users.login = userLogin));
END;

