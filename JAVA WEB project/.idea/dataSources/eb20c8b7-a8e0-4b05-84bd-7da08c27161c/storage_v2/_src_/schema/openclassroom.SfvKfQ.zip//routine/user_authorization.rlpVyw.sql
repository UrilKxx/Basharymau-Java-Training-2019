create
    definer = root@localhost procedure user_authorization(IN loginName varchar(50), IN password varchar(50),
                                                          OUT auth bit, OUT role_short_name varchar(1),
                                                          OUT name varchar(50), OUT userId int)
begin
    set userId = (select openclassroom.users.id from openclassroom.users where openclassroom.users.login = loginName and openclassroom.users.password_hash = MD5(password + '273905'));
    set name = (SELECT openclassroom.users.user_name FROM openclassroom.users WHERE login = loginName);

    if userId > 0 then
        set auth = 1;
        set role_short_name = (SELECT openclassroom.roles.short_name FROM openclassroom.roles INNER JOIN openclassroom.user_roles ON openclassroom.roles.id = openclassroom.user_roles.role_id WHERE openclassroom.user_roles.user_id = userId);
    else
        set auth = 0;
        set role_short_name = null;
    end if;
end;

