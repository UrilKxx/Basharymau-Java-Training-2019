create definer = root@localhost trigger courses_BEFORE_INSERT
    before insert
    on courses
    for each row
BEGIN
	declare roleId int; 
	select role_id from user_roles where user_roles.user_id = NEW.user_id into roleId;
    if roleId != 1 then
		delete from courses where id = new.id;
    end if;
END;

